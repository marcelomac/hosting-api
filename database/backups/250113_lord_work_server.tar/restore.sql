--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.3 (Debian 15.3-1.pgdg120+1)
-- Dumped by pg_dump version 15.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE lord;
--
-- Name: lord; Type: DATABASE; Schema: -; Owner: admin
--

CREATE DATABASE lord WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE lord OWNER TO admin;

\connect lord

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: admin
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Department; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Department" (
    id text NOT NULL,
    name text NOT NULL,
    "folderPath" text,
    description text,
    instructions text,
    phone text,
    "ldapGroupName" text,
    "ldapGroupOU" text,
    active boolean DEFAULT true NOT NULL
);


ALTER TABLE public."Department" OWNER TO admin;

--
-- Name: Email; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Email" (
    id text NOT NULL,
    "movimentId" text NOT NULL,
    "to" text NOT NULL,
    cc text,
    cco text,
    subject text NOT NULL,
    preview text,
    text text,
    html text NOT NULL,
    "sentAt" timestamp(3) without time zone,
    status text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "uniqueKey" text NOT NULL,
    "scriptId" text NOT NULL
);


ALTER TABLE public."Email" OWNER TO admin;

--
-- Name: Employee; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Employee" (
    id text NOT NULL,
    name text NOT NULL,
    cpf text NOT NULL,
    login text,
    sex text NOT NULL,
    phone text NOT NULL,
    email text NOT NULL,
    password text,
    birthdate timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Employee" OWNER TO admin;

--
-- Name: Moviment; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Moviment" (
    id text NOT NULL,
    number text NOT NULL,
    "employeeId" text NOT NULL,
    "departmentId" text,
    "relationshipId" text,
    "ordinanceId" text,
    "movimentType" text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    origin text NOT NULL,
    annotation text,
    status text NOT NULL,
    "statusDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    compliance boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Moviment" OWNER TO admin;

--
-- Name: Ordinance; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Ordinance" (
    id text NOT NULL,
    publication timestamp(3) without time zone NOT NULL,
    "ordinanceType" text NOT NULL,
    number text NOT NULL,
    content text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    "employeeName" text,
    "departmentName" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Ordinance" OWNER TO admin;

--
-- Name: Profile; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Profile" (
    id text NOT NULL,
    theme text NOT NULL,
    "avatarUrl" text NOT NULL,
    "userId" text NOT NULL,
    "openTableFilter" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."Profile" OWNER TO admin;

--
-- Name: Relationship; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Relationship" (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    active boolean DEFAULT true NOT NULL
);


ALTER TABLE public."Relationship" OWNER TO admin;

--
-- Name: Resource; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Resource" (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    active boolean DEFAULT true NOT NULL
);


ALTER TABLE public."Resource" OWNER TO admin;

--
-- Name: ResourceRelationship; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."ResourceRelationship" (
    id text NOT NULL,
    "resourceId" text NOT NULL,
    "relationshipId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ResourceRelationship" OWNER TO admin;

--
-- Name: Script; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Script" (
    id text NOT NULL,
    "movimentId" text NOT NULL,
    "templateId" text NOT NULL,
    number text NOT NULL,
    "scriptContent" text NOT NULL,
    "emailContent" text,
    status text NOT NULL,
    "statusDate" timestamp(3) without time zone NOT NULL,
    "scriptType" text NOT NULL,
    annotation text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Script" OWNER TO admin;

--
-- Name: Setting; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Setting" (
    id text NOT NULL,
    "movimentCreateToDismissal" boolean DEFAULT false NOT NULL,
    "movimentCreateToIngress" boolean DEFAULT false NOT NULL,
    "ordinanceStartDateConfig" text DEFAULT 'lastFetch'::text NOT NULL,
    "ordinanceStartDaysBefore" integer DEFAULT 3 NOT NULL,
    "robotActionsActiveSchedule" boolean DEFAULT false NOT NULL,
    "robotActionsScheduleContent" text,
    "robotFetchOrdinanceActiveSchedule" boolean DEFAULT false NOT NULL,
    "robotFetchOrdinanceScheduleContent" text,
    "scriptExecuteEmailSendAfterCreate" boolean DEFAULT false NOT NULL,
    "scriptExecuteRequestAfterCreate" boolean DEFAULT false NOT NULL,
    "scriptExecuteWebscrapingAfterCreate" boolean DEFAULT false NOT NULL,
    "scriptRemovePendingBeforeCreate" boolean DEFAULT false NOT NULL,
    "scriptCreateAfterRevisedMoviment" boolean DEFAULT false NOT NULL,
    "scriptExecuteCreateEmailAfterCreate" boolean DEFAULT false NOT NULL,
    "keywordsToDismissal" text DEFAULT ''::text,
    "keywordsToEndLicense" text DEFAULT ''::text,
    "keywordsToEndSuspension" text DEFAULT ''::text,
    "keywordsToEndVacation" text DEFAULT ''::text,
    "keywordsToIngress" text DEFAULT ''::text,
    "keywordsToStartLicense" text DEFAULT ''::text,
    "keywordsToStartSuspension" text DEFAULT ''::text,
    "keywordsToStartVacation" text DEFAULT ''::text,
    "movimentCreateToEndLicense" boolean DEFAULT false NOT NULL,
    "movimentCreateToEndSuspension" boolean DEFAULT false NOT NULL,
    "movimentCreateToEndVacation" boolean DEFAULT false NOT NULL,
    "movimentCreateToStartLicense" boolean DEFAULT false NOT NULL,
    "movimentCreateToStartSuspension" boolean DEFAULT false NOT NULL,
    "movimentCreateToStartVacation" boolean DEFAULT false NOT NULL,
    "ordinanceSendEmailDestiny" text,
    "ordinanceSendEmailToDismissal" boolean DEFAULT false NOT NULL,
    "ordinanceSendEmailToEndLicense" boolean DEFAULT false NOT NULL,
    "ordinanceSendEmailToEndSuspension" boolean DEFAULT false NOT NULL,
    "ordinanceSendEmailToEndVacation" boolean DEFAULT false NOT NULL,
    "ordinanceSendEmailToIngress" boolean DEFAULT false NOT NULL,
    "ordinanceSendEmailToStartLicense" boolean DEFAULT false NOT NULL,
    "ordinanceSendEmailToStartSuspension" boolean DEFAULT false NOT NULL,
    "ordinanceSendEmailToStartVacation" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."Setting" OWNER TO admin;

--
-- Name: SysLog; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."SysLog" (
    id text NOT NULL,
    action text NOT NULL,
    message text NOT NULL,
    file text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."SysLog" OWNER TO admin;

--
-- Name: Template; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Template" (
    id text NOT NULL,
    name text NOT NULL,
    "order" integer NOT NULL,
    "resourceId" text NOT NULL,
    "movimentType" text NOT NULL,
    "scriptType" text NOT NULL,
    "scriptContent" text NOT NULL,
    "emailContent" text,
    "sendEmail" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Template" OWNER TO admin;

--
-- Name: User; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."User" (
    id text NOT NULL,
    name text NOT NULL,
    login text NOT NULL,
    password text,
    email text NOT NULL,
    role text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."User" OWNER TO admin;

--
-- Name: UserLog; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."UserLog" (
    id text NOT NULL,
    "userId" text NOT NULL,
    action text NOT NULL,
    message text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."UserLog" OWNER TO admin;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO admin;

--
-- Name: view1; Type: VIEW; Schema: public; Owner: admin
--

CREATE VIEW public.view1 AS
 SELECT "user"."user"
   FROM USER "user"("user");


ALTER TABLE public.view1 OWNER TO admin;

--
-- Data for Name: Department; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Department" (id, name, "folderPath", description, instructions, phone, "ldapGroupName", "ldapGroupOU", active) FROM stdin;
\.
COPY public."Department" (id, name, "folderPath", description, instructions, phone, "ldapGroupName", "ldapGroupOU", active) FROM '$$PATH$$/3565.dat';

--
-- Data for Name: Email; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Email" (id, "movimentId", "to", cc, cco, subject, preview, text, html, "sentAt", status, "createdAt", "uniqueKey", "scriptId") FROM stdin;
\.
COPY public."Email" (id, "movimentId", "to", cc, cco, subject, preview, text, html, "sentAt", status, "createdAt", "uniqueKey", "scriptId") FROM '$$PATH$$/3577.dat';

--
-- Data for Name: Employee; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Employee" (id, name, cpf, login, sex, phone, email, password, birthdate, "createdAt") FROM stdin;
\.
COPY public."Employee" (id, name, cpf, login, sex, phone, email, password, birthdate, "createdAt") FROM '$$PATH$$/3564.dat';

--
-- Data for Name: Moviment; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Moviment" (id, number, "employeeId", "departmentId", "relationshipId", "ordinanceId", "movimentType", date, origin, annotation, status, "statusDate", compliance, "createdAt") FROM stdin;
\.
COPY public."Moviment" (id, number, "employeeId", "departmentId", "relationshipId", "ordinanceId", "movimentType", date, origin, annotation, status, "statusDate", compliance, "createdAt") FROM '$$PATH$$/3563.dat';

--
-- Data for Name: Ordinance; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Ordinance" (id, publication, "ordinanceType", number, content, status, "employeeName", "departmentName", "createdAt") FROM stdin;
\.
COPY public."Ordinance" (id, publication, "ordinanceType", number, content, status, "employeeName", "departmentName", "createdAt") FROM '$$PATH$$/3572.dat';

--
-- Data for Name: Profile; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Profile" (id, theme, "avatarUrl", "userId", "openTableFilter") FROM stdin;
\.
COPY public."Profile" (id, theme, "avatarUrl", "userId", "openTableFilter") FROM '$$PATH$$/3570.dat';

--
-- Data for Name: Relationship; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Relationship" (id, name, description, active) FROM stdin;
\.
COPY public."Relationship" (id, name, description, active) FROM '$$PATH$$/3566.dat';

--
-- Data for Name: Resource; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Resource" (id, name, description, active) FROM stdin;
\.
COPY public."Resource" (id, name, description, active) FROM '$$PATH$$/3567.dat';

--
-- Data for Name: ResourceRelationship; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."ResourceRelationship" (id, "resourceId", "relationshipId", "createdAt") FROM stdin;
\.
COPY public."ResourceRelationship" (id, "resourceId", "relationshipId", "createdAt") FROM '$$PATH$$/3568.dat';

--
-- Data for Name: Script; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Script" (id, "movimentId", "templateId", number, "scriptContent", "emailContent", status, "statusDate", "scriptType", annotation, "createdAt") FROM stdin;
\.
COPY public."Script" (id, "movimentId", "templateId", number, "scriptContent", "emailContent", status, "statusDate", "scriptType", annotation, "createdAt") FROM '$$PATH$$/3573.dat';

--
-- Data for Name: Setting; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Setting" (id, "movimentCreateToDismissal", "movimentCreateToIngress", "ordinanceStartDateConfig", "ordinanceStartDaysBefore", "robotActionsActiveSchedule", "robotActionsScheduleContent", "robotFetchOrdinanceActiveSchedule", "robotFetchOrdinanceScheduleContent", "scriptExecuteEmailSendAfterCreate", "scriptExecuteRequestAfterCreate", "scriptExecuteWebscrapingAfterCreate", "scriptRemovePendingBeforeCreate", "scriptCreateAfterRevisedMoviment", "scriptExecuteCreateEmailAfterCreate", "keywordsToDismissal", "keywordsToEndLicense", "keywordsToEndSuspension", "keywordsToEndVacation", "keywordsToIngress", "keywordsToStartLicense", "keywordsToStartSuspension", "keywordsToStartVacation", "movimentCreateToEndLicense", "movimentCreateToEndSuspension", "movimentCreateToEndVacation", "movimentCreateToStartLicense", "movimentCreateToStartSuspension", "movimentCreateToStartVacation", "ordinanceSendEmailDestiny", "ordinanceSendEmailToDismissal", "ordinanceSendEmailToEndLicense", "ordinanceSendEmailToEndSuspension", "ordinanceSendEmailToEndVacation", "ordinanceSendEmailToIngress", "ordinanceSendEmailToStartLicense", "ordinanceSendEmailToStartSuspension", "ordinanceSendEmailToStartVacation") FROM stdin;
\.
COPY public."Setting" (id, "movimentCreateToDismissal", "movimentCreateToIngress", "ordinanceStartDateConfig", "ordinanceStartDaysBefore", "robotActionsActiveSchedule", "robotActionsScheduleContent", "robotFetchOrdinanceActiveSchedule", "robotFetchOrdinanceScheduleContent", "scriptExecuteEmailSendAfterCreate", "scriptExecuteRequestAfterCreate", "scriptExecuteWebscrapingAfterCreate", "scriptRemovePendingBeforeCreate", "scriptCreateAfterRevisedMoviment", "scriptExecuteCreateEmailAfterCreate", "keywordsToDismissal", "keywordsToEndLicense", "keywordsToEndSuspension", "keywordsToEndVacation", "keywordsToIngress", "keywordsToStartLicense", "keywordsToStartSuspension", "keywordsToStartVacation", "movimentCreateToEndLicense", "movimentCreateToEndSuspension", "movimentCreateToEndVacation", "movimentCreateToStartLicense", "movimentCreateToStartSuspension", "movimentCreateToStartVacation", "ordinanceSendEmailDestiny", "ordinanceSendEmailToDismissal", "ordinanceSendEmailToEndLicense", "ordinanceSendEmailToEndSuspension", "ordinanceSendEmailToEndVacation", "ordinanceSendEmailToIngress", "ordinanceSendEmailToStartLicense", "ordinanceSendEmailToStartSuspension", "ordinanceSendEmailToStartVacation") FROM '$$PATH$$/3571.dat';

--
-- Data for Name: SysLog; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."SysLog" (id, action, message, file, "createdAt") FROM stdin;
\.
COPY public."SysLog" (id, action, message, file, "createdAt") FROM '$$PATH$$/3576.dat';

--
-- Data for Name: Template; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Template" (id, name, "order", "resourceId", "movimentType", "scriptType", "scriptContent", "emailContent", "sendEmail", "createdAt") FROM stdin;
\.
COPY public."Template" (id, name, "order", "resourceId", "movimentType", "scriptType", "scriptContent", "emailContent", "sendEmail", "createdAt") FROM '$$PATH$$/3574.dat';

--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."User" (id, name, login, password, email, role, active, "createdAt") FROM stdin;
\.
COPY public."User" (id, name, login, password, email, role, active, "createdAt") FROM '$$PATH$$/3569.dat';

--
-- Data for Name: UserLog; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."UserLog" (id, "userId", action, message, "createdAt") FROM stdin;
\.
COPY public."UserLog" (id, "userId", action, message, "createdAt") FROM '$$PATH$$/3575.dat';

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
\.
COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM '$$PATH$$/3562.dat';

--
-- Name: Department Department_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Department"
    ADD CONSTRAINT "Department_pkey" PRIMARY KEY (id);


--
-- Name: Email Email_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Email"
    ADD CONSTRAINT "Email_pkey" PRIMARY KEY (id);


--
-- Name: Employee Employee_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Employee"
    ADD CONSTRAINT "Employee_pkey" PRIMARY KEY (id);


--
-- Name: Moviment Moviment_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Moviment"
    ADD CONSTRAINT "Moviment_pkey" PRIMARY KEY (id);


--
-- Name: Ordinance Ordinance_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Ordinance"
    ADD CONSTRAINT "Ordinance_pkey" PRIMARY KEY (id);


--
-- Name: Profile Profile_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Profile"
    ADD CONSTRAINT "Profile_pkey" PRIMARY KEY (id);


--
-- Name: Relationship Relationship_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Relationship"
    ADD CONSTRAINT "Relationship_pkey" PRIMARY KEY (id);


--
-- Name: ResourceRelationship ResourceRelationship_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."ResourceRelationship"
    ADD CONSTRAINT "ResourceRelationship_pkey" PRIMARY KEY (id);


--
-- Name: Resource Resource_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Resource"
    ADD CONSTRAINT "Resource_pkey" PRIMARY KEY (id);


--
-- Name: Script Script_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Script"
    ADD CONSTRAINT "Script_pkey" PRIMARY KEY (id);


--
-- Name: Setting Setting_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Setting"
    ADD CONSTRAINT "Setting_pkey" PRIMARY KEY (id);


--
-- Name: SysLog SysLog_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SysLog"
    ADD CONSTRAINT "SysLog_pkey" PRIMARY KEY (id);


--
-- Name: Template Template_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Template"
    ADD CONSTRAINT "Template_pkey" PRIMARY KEY (id);


--
-- Name: UserLog UserLog_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."UserLog"
    ADD CONSTRAINT "UserLog_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Email_uniqueKey_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "Email_uniqueKey_key" ON public."Email" USING btree ("uniqueKey");


--
-- Name: Employee_cpf_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "Employee_cpf_key" ON public."Employee" USING btree (cpf);


--
-- Name: Moviment_number_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "Moviment_number_key" ON public."Moviment" USING btree (number);


--
-- Name: Ordinance_number_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "Ordinance_number_key" ON public."Ordinance" USING btree (number);


--
-- Name: Profile_userId_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "Profile_userId_key" ON public."Profile" USING btree ("userId");


--
-- Name: Script_number_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "Script_number_key" ON public."Script" USING btree (number);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_login_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "User_login_key" ON public."User" USING btree (login);


--
-- Name: Email Email_movimentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Email"
    ADD CONSTRAINT "Email_movimentId_fkey" FOREIGN KEY ("movimentId") REFERENCES public."Moviment"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Moviment Moviment_departmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Moviment"
    ADD CONSTRAINT "Moviment_departmentId_fkey" FOREIGN KEY ("departmentId") REFERENCES public."Department"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Moviment Moviment_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Moviment"
    ADD CONSTRAINT "Moviment_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Moviment Moviment_ordinanceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Moviment"
    ADD CONSTRAINT "Moviment_ordinanceId_fkey" FOREIGN KEY ("ordinanceId") REFERENCES public."Ordinance"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Moviment Moviment_relationshipId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Moviment"
    ADD CONSTRAINT "Moviment_relationshipId_fkey" FOREIGN KEY ("relationshipId") REFERENCES public."Relationship"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Profile Profile_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Profile"
    ADD CONSTRAINT "Profile_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ResourceRelationship ResourceRelationship_relationshipId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."ResourceRelationship"
    ADD CONSTRAINT "ResourceRelationship_relationshipId_fkey" FOREIGN KEY ("relationshipId") REFERENCES public."Relationship"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ResourceRelationship ResourceRelationship_resourceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."ResourceRelationship"
    ADD CONSTRAINT "ResourceRelationship_resourceId_fkey" FOREIGN KEY ("resourceId") REFERENCES public."Resource"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Script Script_movimentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Script"
    ADD CONSTRAINT "Script_movimentId_fkey" FOREIGN KEY ("movimentId") REFERENCES public."Moviment"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Script Script_templateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Script"
    ADD CONSTRAINT "Script_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES public."Template"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Template Template_resourceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Template"
    ADD CONSTRAINT "Template_resourceId_fkey" FOREIGN KEY ("resourceId") REFERENCES public."Resource"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserLog UserLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."UserLog"
    ADD CONSTRAINT "UserLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: admin
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

